package com.university;


class SpringEcommerceApplicationTests {

	void contextLoads() {
	}

}

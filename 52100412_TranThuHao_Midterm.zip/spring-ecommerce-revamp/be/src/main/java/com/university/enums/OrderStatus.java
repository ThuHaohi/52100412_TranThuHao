package com.university.enums;

public enum OrderStatus {
	PENDING, DELIVERED
}
